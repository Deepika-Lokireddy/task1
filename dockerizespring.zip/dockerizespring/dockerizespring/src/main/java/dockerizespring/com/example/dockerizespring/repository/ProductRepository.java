package dockerizespring.com.example.dockerizespring.repository;

import dockerizespring.com.example.dockerizespring.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductRepository extends JpaRepository<Product,Integer> {
}
