package dockerizespring.com.example.dockerizespring.controller;

import dockerizespring.com.example.dockerizespring.model.Product;
import dockerizespring.com.example.dockerizespring.services.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/products")
public class ProductController {
    @Autowired
    private ProductService productService;
    @PostMapping("/addproduct")
    public Product addProduct(@RequestBody Product product)
    {
      return productService.saveProduct(product);
    }
    @GetMapping("/getproduct")
    public List<Product> sendProducts()
    {
        return productService.getproducts();
    }
    @GetMapping("/getproduct/{id}")
    public Product sendProductById(@PathVariable int id)
    {
        return productService.getProductById(id);
    }
    @PutMapping("/updateproduct/{id}")
    public Product aupdateProduct(@PathVariable(value = "id") Integer Id ,@RequestBody Product product)
    {
        return productService.updateProduct(product,Id);
    }
    @DeleteMapping("/delete/{id}")
    public String deleteProduct(@PathVariable int id)
    {
        return productService.deleteProductById(id);
    }

}
